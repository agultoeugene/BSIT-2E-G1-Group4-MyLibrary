const api = "/BSIT-2E-G1-Group4-MyLibrary/backend/controllers/login.php";
$(document).ready(function() {

    $("#loginForm").on("submit", function(e){
        e.preventDefault(); 
        postOne(); 
    });

    $("#email").on("input", function() {
        $("#errEmail").text("");
    });

    $("#password").on("input", function() {
        $("#errPassword").text("");
    });

    $('#loginModal').on('hidden.bs.modal', function () {
        $("#errEmail").text("");
        $("#errPassword").text("");
        $("#email").val("");      
        $("#password").val("");   
    });
});
function postOne() {
  let email = $("#email").val();
  let password = $("#password").val();
  
  let errEmail = $("#errEmail");
  let errPassword = $("#errPassword");

  errEmail.text("");
  errPassword.text("");

  if (email == "") {
    errEmail.text("Please input your Email!"); 
    return false;
  }

  if (password == "") {
    errPassword.text("Please input your Password!");
    return false;
  }

  let payload = {
      email : email,
      password : password
  }

  $.ajax({
     url : api,
     type : "POST",
     data: {
                    action: "postOne",
                    payload: JSON.stringify(payload)
           },
     dataType: "json",
     success : function (response) {
        
           if (response.status == "success") {
           Swal.fire({
            icon: "success",
            title: response.message,
            timer: 1500,
            showConfirmButton: false
        }).then(() => {
            window.location.href = "/BSIT-2E-G1-Group4-MyLibrary/system/pages/dashboard.php";
        });

        } else {

            Swal.fire({
                title: "Error!",
                text: response.message,
                icon: "error"
            });

        }
    },
     error : function (error) {
			      alert(error.message);
	    	  }
  })
}
