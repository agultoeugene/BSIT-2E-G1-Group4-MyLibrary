<?php
  include("../includes/navigation.php");
?> 
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>My Library - About Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/navigation.css">
    <link rel="stylesheet" href="../assets/css/contact.css">
     <link rel="stylesheet" href="../assets/css/home.css">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
</head>

<body class="bg-body-tertiary ">
 
<div class="container pt-5 mt-5">
      <h1 class="page-title text-center">Contact Us</h1>

      <div class="row justify-content-between align-items-start g-5">
        <div class="col-lg-5">
          <h2 class="contact-header">Are you facing any issues?</h2>
          <p class="contact-text">
            We are working hard to ensure you have the best experience with our
            web app. Contact us today if you are facing any issues; we are
            reviewing all feedback immediately to provide you with fast and
            reliable support.
          </p>

          <div class="info-item">
            <i class="fa-regular fa-envelope"></i>
            <span>librarymanagementwebapp@gmail.com</span>
          </div>
          <div class="info-item">
            <i class="fa-solid fa-house-chimney"></i>
            <span>Bulihan, Malolos City, Bulacan</span>
          </div>
          <div class="info-item">
            <i class="fa-solid fa-phone"></i>
            <span>+123 456 7890 1011</span>
          </div>
        </div>

        <div class="col-lg-6">
          <form id="contactForm" class="contact-form">
            <div class="mb-3">
              <input
                type="text"
                class="form-control custom-input"
                placeholder="Name"
                required
              />
            </div>
            <div class="mb-3">
              <input
                type="email"
                class="form-control custom-input"
                placeholder="Email"
                required
              />
            </div>
            <div class="mb-3">
              <textarea
                class="form-control custom-input"
                placeholder="Message here..."
                rows="5"
                required
              ></textarea>
            </div>
            <button type="submit" class="btn-submit">Submit</button>
          </form>
        </div>
      </div>
    </div>

    <div id="successPopUp" class="success-popup">
      <div class="popup-content">
        <i class="fa-solid fa-circle-check"></i>
        <span>Message sent successfully!</span>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
      document
        .getElementById("contactForm")
        .addEventListener("submit", function (e) {
          e.preventDefault();
          const popup = document.getElementById("successPopUp");
          popup.classList.add("show");
          this.reset();

          setTimeout(() => {
            popup.classList.remove("show");
          }, 4000);
        });
    </script>
        <script src="https://code.jquery.com/jquery-4.0.0.js" integrity="sha256-9fsHeVnKBvqh3FB2HYu7g2xseAZ5MlN6Kz/qnkASV8U=" crossorigin="anonymous"></script> 
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/script/login.js"></script> 
        <script src="../assets/script/register.js"></script>  
    </body>
</html>